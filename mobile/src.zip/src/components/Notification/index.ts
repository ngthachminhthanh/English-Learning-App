import NotiComponent from './NotiComponent'
export default NotiComponent