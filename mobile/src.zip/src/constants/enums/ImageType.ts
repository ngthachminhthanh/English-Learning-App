enum ImageType {
    png = 'image/png',
    jpeg = 'image/jpeg',
    jpg = 'image/jpg',
    gif = 'image/gif',
}
export default ImageType;