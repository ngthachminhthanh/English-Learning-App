enum SectionType {
  ROOT = "root",
  READING = "reading",
  LISTENING = "listening",
  VOCABULARY = "vocabulary",
}
export default SectionType;
