import Vocabulary from "./Vocabulary";

export default Vocabulary;