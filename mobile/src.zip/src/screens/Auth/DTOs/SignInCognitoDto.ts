type SignInCognitoDto = {
    username: string;
    password: string;
  };
  export default SignInCognitoDto;