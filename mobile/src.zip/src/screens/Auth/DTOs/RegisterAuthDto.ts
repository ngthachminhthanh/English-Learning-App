type RegisterAuthDto = {
    username: string;
    email: string;
    password: string;
    role: string;
    firstName: string;
    lastName: string;
    phone: string;
    birthDate: string;
  };
  export default RegisterAuthDto;