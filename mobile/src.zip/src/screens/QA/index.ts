import QuestionScreen from "./QuestionScreen";
export default QuestionScreen;