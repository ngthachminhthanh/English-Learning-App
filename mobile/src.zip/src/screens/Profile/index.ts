import Profile from "./Profile";

export default Profile;