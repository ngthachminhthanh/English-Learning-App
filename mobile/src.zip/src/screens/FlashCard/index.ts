import FlashCard from "./FlashCard";

export default FlashCard;