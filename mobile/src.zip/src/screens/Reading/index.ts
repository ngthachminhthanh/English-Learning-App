import Reading from "./ReadingExercise";

export default Reading;