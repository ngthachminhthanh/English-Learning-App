import Grammar from "./Grammar";

export default Grammar;