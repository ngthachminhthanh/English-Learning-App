import Learning from "./LearningScreen";

export default Learning;