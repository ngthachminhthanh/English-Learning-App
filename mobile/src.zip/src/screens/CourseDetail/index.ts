import CourseDetail from "./CourseDetail";
export default CourseDetail;