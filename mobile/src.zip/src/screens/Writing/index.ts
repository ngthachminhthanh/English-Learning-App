import Writing from "./WritingExercise";

export default Writing;