type GrammarModel = {
  id: string;
  description: string;
  createDate?: string;
  updateDate?: string;
  title: string;
  content?: string;
};
export default GrammarModel;
