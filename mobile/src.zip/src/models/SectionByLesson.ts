type SectionByLesson = {
    id: string;
    createDate: string;
    updateDate: string;
    title: string;
    content: string;
    type: string;
    lessonId: string;
  };
  export default SectionByLesson;
  