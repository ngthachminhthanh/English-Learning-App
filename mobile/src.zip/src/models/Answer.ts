type Answer={
    id: string;
    createDate: string;
    updateDate: string;
    text: string;
    isCorrect: boolean;
}